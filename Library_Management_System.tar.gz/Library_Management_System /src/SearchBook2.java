import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;


public class SearchBook2 extends JFrame implements ActionListener 
{
	private static final long serialVersionUID = 1L;
	Connection con = null;
    Statement st = null;
    ResultSet rst=null;
    PreparedStatement pst=null;
    JFrame f1=new JFrame();
    java.sql.ResultSetMetaData rst1;
	//Vector data= new Vector();
	//Vector row =new Vector();

	JLabel l1,l2;
	JTextField t1,t2;
	JPasswordField ps1;
	JButton b1,b2,b3,b4;
	JMenu login,search,About;
	JMenuItem i1,i2,i3,i4,i5,i6;
///	ArrayList columnNames=new ArrayList();
	
	//ArrayList data =new ArrayList();
	
	JMenuBar mb;
	JPanel p1;	

	public SearchBook2()
	{
		// super("Add component on JFrame at runtime");	
		
		l1=new JLabel("Search Books");
		l1.setForeground(Color.BLUE);
		Font f= new Font("Italic" ,Font.ITALIC,25);
		l1.setFont(f);
		l2=new JLabel("Enter title or Author or Isbn Of Book to Search");
		
		b1=new JButton("Search by Title");
		b2=new JButton("Search by Author");
		b3=new JButton("Search by ISBN");
		b4=new JButton("Back");
		
		
		p1=new JPanel();		
        t1=new JTextField();
       
        l1.setBounds(250, 20, 200, 30);
        l2.setBounds(150, 100, 350, 60);
        
        
        b1.setBounds(200, 200, 300, 30);  
        b2.setBounds(200, 250, 300, 30);
       b3.setBounds(200, 300, 300, 30);
       b4.setBounds(500, 350, 200, 30);
        t1.setBounds(550, 120, 250, 30);       
        p1.setBounds(0, 0, 900, 500);        
        p1.setBackground(Color.cyan );        
        JMenuBar mb=new JMenuBar();
		login=new JMenu("Login");
		search=new JMenu("Search Book");
		About=new JMenu("About");
		
        p1.add(l1);
        p1.add(l2);
        p1.add(t1);
        
        p1.add(b1);
        p1.add(b2);
        p1.add(b3);
        p1.add(b4);
        
      
       f1.add(p1);
       
     
       
      
       p1.setLayout(null);
            
        b1.addActionListener(this);
        b2.addActionListener(this);
        b3.addActionListener(this);
        
        b4.addActionListener(this);
        f1.setSize(900, 500);
        f1.setLayout(null);
        f1.setLocationRelativeTo(null);
        
        f1.setVisible(true);
        
	
	
	try{
		Class.forName("com.mysql.jdbc.Driver");
		  con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Library","root","root");
		 st = con.createStatement();
		 if(con!=null)
		 {
			 JOptionPane.showMessageDialog(null, "connected to database"); 
		 }
         
	}catch(Exception ex)
	{
		JOptionPane.showMessageDialog(null,ex.getMessage());
	}
	
}

	

@Override
public void actionPerformed(ActionEvent e)
{
	
	
	if(e.getSource()== b1)
	
	
	{
		
			try{
				String in1=t1.getText();
					String data1 =null;
					st=con.createStatement();
					
					pst= con.prepareStatement("select * from Books where Title like ?");
					
					pst.setString(1,"%" +in1+ "%" );
					rst= pst.executeQuery();
					rst1=rst.getMetaData();
					int c=rst1.getColumnCount();
					Vector column=new Vector(c);
					for(int i=1;i<=c;i++)
					{
						column.add(rst1.getColumnName(i));
						
					}
					Vector data= new Vector();
					Vector row =new Vector();
					while(rst.next())
						
					{
						row=new Vector(c);
						for(int i=1;i<=c;i++)
						{
							row.add(rst.getString(i));
							
						}
						data.add(row);
					}
					JFrame frame=new JFrame();
					frame.setSize(800, 500);
					frame.setLocationRelativeTo(null);
					frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
					JPanel panel = new JPanel();
					JTable table =new JTable(data,column);
					JScrollPane jsp=new JScrollPane(table);
					
					
					panel.setLayout(new BorderLayout());
					panel.add(jsp,BorderLayout.CENTER);
					frame.setContentPane(panel);
					frame.setVisible(true);
				}
					
				catch(Exception e2)
				
				{
					e2.printStackTrace();
				}
					
				}
        

	if(e.getSource()== b2)
	
	
	{
		
		try{
			String in1=t1.getText();
			String data1 =null;
			st=con.createStatement();
			
			pst= con.prepareStatement("select * from Books where Author = ?");
			
			pst.setString(1,in1);
			rst= pst.executeQuery();
			rst1=rst.getMetaData();
			int c=rst1.getColumnCount();
			Vector column=new Vector(c);
			for(int i=1;i<=c;i++)
			{
				column.add(rst1.getColumnName(i));
				
			}
			Vector data= new Vector();
			Vector row =new Vector();
			while(rst.next())
				
			{
				row=new Vector(c);
				for(int i=1;i<=c;i++)
				{
					row.add(rst.getString(i));
					
				}
				data.add(row);
			}
			JFrame frame=new JFrame();
			frame.setSize(800, 500);
			frame.setLocationRelativeTo(null);
			frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			JPanel panel = new JPanel();
			JTable table =new JTable(data,column);
			JScrollPane jsp=new JScrollPane(table);
			
			
			panel.setLayout(new BorderLayout());
			panel.add(jsp,BorderLayout.CENTER);
			frame.setContentPane(panel);
			frame.setVisible(true);
		}
			
			
		catch(Exception ex)
        {
        	JOptionPane.showMessageDialog(null,ex.getMessage());
        }


        }

		
					
		


        
	

	if(e.getSource()== b3)
	
	
	{
		
		try{
			String in1=t1.getText();
			String data1 =null;
			st=con.createStatement();
			//rst=st.executeQuery("select  * from Books where Title= ? ");
			pst= con.prepareStatement("select * from Books where BookIsbn = ?");
			//rst=st.executeQuery("select  * from Books where Title= ?  ");
			pst.setString(1,in1);
			rst= pst.executeQuery();
			rst1=rst.getMetaData();
			int c=rst1.getColumnCount();
			Vector column=new Vector(c);
			for(int i=1;i<=c;i++)
			{
				column.add(rst1.getColumnName(i));
				
			}
			Vector data= new Vector();
			Vector row =new Vector();
			while(rst.next())
				
			{
				row=new Vector(c);
				for(int i=1;i<=c;i++)
				{
					row.add(rst.getString(i));
					
				}
				data.add(row);
			}
			JFrame frame=new JFrame();
			frame.setSize(800, 500);
			frame.setLocationRelativeTo(null);
			frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			JPanel panel = new JPanel();
			JTable table =new JTable(data,column);
			JScrollPane jsp=new JScrollPane(table);
			
			
			panel.setLayout(new BorderLayout());
			panel.add(jsp,BorderLayout.CENTER);
			frame.setContentPane(panel);
			frame.setVisible(true);
			
		}catch(Exception ex)
        {
        	JOptionPane.showMessageDialog(null,ex.getMessage());
        }


        }
	if(e.getSource()== b4)
		
		
	{
		new Login();
	}
			
	

	
		}
	
			
		
	
		
	
	



public static void main(String args[])
{
	new SearchBook2();

}

}






