



import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.format.DateTimeFormatter;
import java.util.Vector;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import java.util.Calendar;
import java.util.Date;
import java.util.Properties;

import org.jdatepicker.impl.*;
import org.jdatepicker.util.*;
import org.jdatepicker.*;

import org.jdatepicker.impl.JDatePanelImpl;
import org.jdatepicker.impl.JDatePickerImpl;
import org.jdatepicker.impl.UtilDateModel;

import com.mysql.jdbc.PreparedStatement;

public class SearchUserBooks extends JFrame implements ActionListener{
	JPanel p1,p2;
	JLabel l,l1,l2,l3,l4,l5,l6;
	JTextField t1,t2,t3,t4,t5,t6;
	JButton b1,b2,b3;
	Connection con;
	Statement stmt;
	ResultSet rst,rs1;
	PreparedStatement pst,pst1;
	java.sql.ResultSetMetaData rst1;
	
	
	
	public SearchUserBooks()
	{
		JFrame f1=new JFrame();
		
		l1=new JLabel("User_ID");
		
		
		t1=new JTextField(20);    
	
		
		b1=new JButton("Search Which Books  User is having ");
		b2=new JButton("Search No of Books ");
		l1.setBounds(80, 100, 80, 30);
				
		t1.setBounds(150, 100, 250, 30);
		//t2.setBounds(100, 80, 100, 30);		
		b1.setBounds(50,310 ,300 , 30);
		b2.setBounds(50,350 ,300 , 30);
		 JPanel p1=new JPanel();
		p1.setBounds(0, 0, 900, 500);
		p1.setBackground(Color.cyan );				
		f1.add(l1);
		f1.add(t1);				
		f1.add(b1);
		f1.add(b2);
		f1.add(p1);		
		 b1.addActionListener(this);
		 b2.addActionListener(this);
		f1.setSize(900, 500);
        f1.setLayout(null);
        f1.setLocationRelativeTo(null);
       
		
	
		f1.setTitle("Search Books User has");
		f1.setVisible(true);
		f1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		
		 try{
	        	Class.forName("com.mysql.jdbc.Driver");
	        	  con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Library","root","root");
	        	 stmt = con.createStatement();
	        	 if(con!=null)
	        	 {
	        		 JOptionPane.showMessageDialog(null, "connected to database"); 
	        	 }
	             
	        }catch(Exception ex)
	        {
	        	JOptionPane.showMessageDialog(null,ex.getMessage());
	        }


	        }
	public void actionPerformed(ActionEvent e) {
				if(e.getSource()==b1)
		{
					//pst=(PreparedStatement) con.prepareStatement("select * from User_Books where ID = ?");
				try{
					String in1=t1.getText();
					
					 Pattern pattern2 = Pattern.compile("[a-z0-9].{7,10}");


				        Matcher mat2 = pattern2.matcher(in1);
				        
				        if(mat2.matches())
				        	
				        	
				        {
					String data1 =null;
					stmt=con.createStatement();
					pst=(PreparedStatement) con.prepareStatement("select * from User_Books where ID = ?");
					
					pst.setString(1,in1);
					rst= pst.executeQuery();
					rst1=rst.getMetaData();
					int c=rst1.getColumnCount();
					Vector column=new Vector(c);
					for(int i=1;i<=c;i++)
					{
						column.add(rst1.getColumnName(i));
						
					}
					Vector data= new Vector();
					Vector row =new Vector();
					while(rst.next())
						
					{
						row=new Vector(c);
						for(int i=1;i<=c;i++)
						{
							row.add(rst.getString(i));
							
						}
						data.add(row);
					}
					JFrame frame=new JFrame();
					frame.setSize(800, 500);
					frame.setLocationRelativeTo(null);
					frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
					JPanel panel = new JPanel();
					JTable table =new JTable(data,column);
					JScrollPane jsp=new JScrollPane(table);
					
					
					panel.setLayout(new BorderLayout());
					panel.add(jsp,BorderLayout.CENTER);
					frame.setContentPane(panel);
					frame.setVisible(true);
					
				}
				        else{

					           
				        	JOptionPane.showMessageDialog(null,"notvalid e-mail or Mobile No or Please check your password it must have  atleast 6 chracter and atmost 10 chracter ");
				        }
				}
				        catch(Exception ex)
		        {
		        	JOptionPane.showMessageDialog(null,ex.getMessage());
		        }


		        }
				if(e.getSource()==b2)
				{
					
						try{
							String in1=t1.getText();
							
							Pattern pattern2 = Pattern.compile("[a-z0-9].{7,10}");


					        Matcher mat2 = pattern2.matcher(in1);
					        
					        if(mat2.matches())
					        	
					        	
					        {
							String data1 =null;
							stmt=con.createStatement();
							pst=(PreparedStatement) con.prepareStatement("select ID,Count(ID) from User_Books where ID=? group by ID");

							//rst=st.executeQuery("select * from Books where Title = ? " );
							pst.setString(1,in1);
							rst= pst.executeQuery();
							
							rst1=rst.getMetaData();
							int c=rst1.getColumnCount();
							Vector column=new Vector(c);
							for(int i=1;i<=c;i++)
							{
								column.add(rst1.getColumnName(i));
								
							}
							Vector data= new Vector();
							Vector row =new Vector();
						
							while(rst.next())
							{
								for(int i=1;i<=c;i++)
								{
									row.add(rst.getString(i));
									
								}
							}
							
							
					
							
							data.add(row);
							
							JFrame frame=new JFrame();
							frame.setSize(800, 400);
							frame.setLocationRelativeTo(null);
							frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
							JPanel panel = new JPanel();
							JTable table =new JTable(data,column);
							JScrollPane jsp=new JScrollPane(table);
							
							
							panel.setLayout(new BorderLayout());
							panel.add(jsp,BorderLayout.CENTER);
							frame.setContentPane(panel);
							frame.setVisible(true);
						
						}
					        
					        else{

						           
					        	JOptionPane.showMessageDialog(null,"notvalid e-mail or Mobile No or Please check your password it must have  atleast 6 chracter and atmost 10 chracter ");
					        }
						}catch(Exception ex)
				        {
				        	JOptionPane.showMessageDialog(null,ex.getMessage());
				        }


				        }
							
					
					
			

			
				}
			
					
				
			
				
		
		
		
	
	
		
		
		
		
	





	
		public static void main (String[] args)
	{
		new SearchUserBooks();
	}

}

		