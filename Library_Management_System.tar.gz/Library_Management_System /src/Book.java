import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.math.BigInteger;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;

import com.mysql.jdbc.PreparedStatement;


public class Book extends JFrame implements ActionListener {
	
	JLabel l1,l2,l3,l4,l5 ,l6;
	JTextField t1,t2,t3,t4,t5,t6;
	JButton b1,b2,b3,b4;
	Connection con;
	Statement stmt;
	ResultSet rst;
	JPanel p1=new JPanel();
	PreparedStatement pst;
	java.sql.ResultSetMetaData rst1;
	
	
	public Book ()
	{
		JFrame f1=new JFrame();
		l1=new JLabel("Access_No");
		l2=new JLabel("Book ISBN");
		l3=new JLabel("Author");
		l4=new JLabel("Title");
		l5=new JLabel("Description");
		l6=new JLabel("No of copies");
		
		b1=new JButton("Add");
		b2=new JButton("Edit");
		b3=new JButton("View");
		b4=new JButton("Back");
		
		
		t1=new JTextField(" eg It must Start with CS or EC and contains atleast 6digit eg CS123");
		t2=new JTextField(" eg 0-596-52068-9 or 978-93-346-0138-6");
		t3=new JTextField(20);
		t4=new JTextField(20);
		t5=new JTextField(20);
		t6=new JTextField(20);
		
		//l6.setBounds(100, 0, 150, 30);
		
		l1.setBounds(100, 30, 80, 50);
		l2.setBounds(100, 80, 90, 30);
		l3.setBounds(100, 130, 90, 30);
		l4.setBounds(100, 180, 90, 30);
		l5.setBounds(100, 230, 90, 30);
		l6.setBounds(100, 280, 90, 30);
		
		t1.setBounds(200, 30, 350, 30);
		t2.setBounds(200, 80, 350, 30);
		t3.setBounds(200, 130, 350, 30);
		t4.setBounds(200, 180, 350, 30);
		t5.setBounds(200, 230, 350, 30);
		t6.setBounds(200, 280, 350, 30);
		
		
		b1.setBounds(100,350,100,30);
		b3.setBounds(250,350,100,30);
		b4.setBounds(380, 350, 100,30);
		//b4.setBounds(500, 350, 100,30);
		
		JPanel p1=new JPanel();
		p1.setBounds(0, 0, 900, 500);
		 p1.setBackground(Color.cyan );

		
		f1.add(l1);
		f1.add(l2);
		f1.add(l3);
		f1.add(l4);
		f1.add(l5);
	//	f1.add(l6);

	
		f1.add(b1);
	//	f1.add(b2);
		f1.add(b3);
		f1.add(b4);
		
		
		f1.add(t1);
		f1.add(t2);
		f1.add(t3);
		f1.add(t4);
		f1.add(t5);
		//f1.add(t6);
		f1.add(p1);
		
		 b1.addActionListener(this);
		  b2.addActionListener(this);
		  b3.addActionListener(this);
		  b4.addActionListener(this);
		
		f1.setSize(900, 500);
        f1.setLayout(null);
        f1.setLocationRelativeTo(null);
        f1.setTitle(" ADD BOOKS");
        
        f1.setVisible(true);
        
        try{
        	Class.forName("com.mysql.jdbc.Driver");
        	  con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Library","root","root");
        	 stmt = con.createStatement();
        	 if(con!=null)
        	 {
        		 JOptionPane.showMessageDialog(null, "connected to database"); 
        	 }
             
        }catch(Exception ex)
        {
        	JOptionPane.showMessageDialog(null,ex.getMessage());
        }


        }

	
	public void actionPerformed(ActionEvent e)
		{
		if(e.getSource()==b1)
		{
			try{
				 // int in1=Integer.parseInt(t1.getText());
				  String in1=t1.getText();
				  String in2=t2.getText();
				 String in3=t3.getText();
				  String in4=t4.getText();
				  String in5=t5.getText();
				 
				//  int in6=Integer.parseInt(t6.getText());
				  
				  // For 10 digit ISBN 
				  //0-596-52068-9,0 512 52068 9,ISBN-10 0-596-52068-9,ISBN-10: 0-596-52068-9
				  
			//	 Pattern pattern1 = Pattern.compile( "^(?:ISBN(?:-10)?:? )?(?=[0-9X]{10}$|(?=(?:[0-9]+[- ]){3})[- 0-9X]{13}$)[0-9]{1,5}[- ]?[0-9]+[- ]?[0-9]+[- ]?[0-9X]$");
			    //   Matcher mat1 = pattern1.matcher(in2);
			     
				  //for 13 digit ISBN
			     //  Pattern pattern2 = Pattern.compile( "^(?:ISBN(?:-13)?:? )?(?=[0-9]{13}$|(?=(?:[0-9]+[- ]){4})[- 0-9]{17}$)97[89][- ]?[0-9]{1,5}[- ]?[0-9]+[- ]?[0-9]+[- ]?[0-9]$" );
			     //  Matcher mat2 = pattern2.matcher(in2);
			       
				  //for both 10 and 13 digit
				  
			       Pattern pattern2 = Pattern.compile( "^(?:ISBN(?:-1[03])?:? )?(?=[0-9X]{10}$|(?=(?:[0-9]+[- ]){3})[- 0-9X]{13}$|97[89][0-9]{10}$|(?=(?:[0-9]+[- ]){4})[- 0-9]{17}$)(?:97[89][- ]?)?[0-9]{1,5}[- ]?[0-9]+[- ]?[0-9]+[- ]?[0-9X]$" );
			       Matcher mat2 = pattern2.matcher(in2);
			       
			      //Pattern pattern = Pattern.compile("[0-9].{6,10}");
			       
			     //  Pattern pattern = Pattern.compile("[a-z0-9].{7,10}");

			//       Matcher mat = pattern.matcher(in1);
			       
			       
			       
			       
			       
				 
				 
			
			        if(mat2.matches())
			       {
				
				  pst=(PreparedStatement) con.prepareStatement("insert into Books(access_No,BookIsbn,Author,Title,Description) values(?,?,?,?,?)");
				  
				  pst.setString(1, in1);
				  pst.setString(2, in2);
				  pst.setString(3, in3);
				  pst.setString(4, in4);
				  pst.setString(5, in5);
				//  pst.setString(5, in2);
				 // pst.setInt(5, (int)(in6));
				 
				 ///pst.setFloat(5, Float.parseFloat(in5));
				  pst.executeUpdate();
				  JOptionPane.showMessageDialog(null, "data inserted");
			        } 
			        
			       else{

				           
			        	JOptionPane.showMessageDialog(null,"notvalid  valid Isbn ");
			       }
		}
			        
			  catch(SQLException e2){
				  JOptionPane.showMessageDialog(null, e2.getMessage());
				  
				  
			  }
			  
		  }
		
		if(e.getSource()==b4)
			
		{
			new interface1();
			
		}
		
	if(e.getSource()==b3)  //view button
			
		{
		try{
			String data1 =null;
			stmt=con.createStatement();
			rst=stmt.executeQuery("select  * from Books   ");
			rst1=rst.getMetaData();
			int c=rst1.getColumnCount();
			Vector column=new Vector(c);
			for(int i=1;i<=c;i++)
			{
				column.add(rst1.getColumnName(i));
				
			}
			Vector data= new Vector();
			Vector row =new Vector();
			while(rst.next())
				
			{
				row=new Vector(c);
				for(int i=1;i<=c;i++)
				{
					row.add(rst.getString(i));
					
				}
				data.add(row);
			}
			JFrame frame=new JFrame();
			frame.setSize(800, 500);
			frame.setLocationRelativeTo(null);
			frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			JPanel panel = new JPanel();
			JTable table =new JTable(data,column);
			JScrollPane jsp=new JScrollPane(table);
			
			
			panel.setLayout(new BorderLayout());
			panel.add(jsp,BorderLayout.CENTER);
			frame.setContentPane(panel);
			frame.setVisible(true);
		}
			
		catch(Exception e2)
		
		{
			e2.printStackTrace();
		}
			
		}
		}
		  
		  
		  
				
		
					
	public static void main(String args[])
	{
		new Book();
	}
	
	

}
