import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;

import com.mysql.jdbc.PreparedStatement;


public class User extends JFrame implements ActionListener {
	
	JLabel l1,l2,l3,l4,l5,l6,l7,l8;
	JTextField t1,t2,t3,t4,t5,t6,t7,t8;
	JButton b1,b2,b3;
	JPanel p1,p2;
	Connection con;
	Statement stmt;
	ResultSet rst;
	PreparedStatement pst;
	JComboBox Dept, Designation;
	java.sql.ResultSetMetaData rst1;
	
	
	
	
	public User ()
	{
		JFrame f1=new JFrame();
		l6=new JLabel("ADD USER");
		l1=new JLabel("Name");
		l2=new JLabel("ID");
		l3=new JLabel("E-mail");
		l4=new JLabel("Address");
		l5=new JLabel("Contact");
		l7=new JLabel("Dept");
		l8=new JLabel("Designation");
		
		b1=new JButton("Add");
		b2=new JButton("Back");
		b3=new JButton("View");
		
		t1=new JTextField(20);
		t2=new JTextField(20);
		t3=new JTextField(20);
		t4=new JTextField(20);
		t5=new JTextField(20);
		t7=new JTextField(20);		
		t8=new JTextField(20);
		
		 Dept = new JComboBox();		 
		
		  Designation = new JComboBox();
		 
		// add items to the combo box
		  
		  Dept.addItem("CSE");
			 Dept.addItem("ECE");
		//	 Dept.addItem("Tecnical Staff");
			
		 Designation.addItem("Student");
		 Designation.addItem("Faculty");
		 Designation.addItem("Tecnical Staff");
		
		
		
		l6.setBounds(200, 0, 150, 30);
		
	l1.setBounds(50, 30, 80, 30);
	l2.setBounds(50, 80, 80, 30);
	l3.setBounds(50, 130, 80, 30);
	l4.setBounds(50, 180, 80, 30);
	l5.setBounds(50, 230, 80, 30);
		l7.setBounds(50, 280, 80, 30);
		l8.setBounds(50, 330, 100, 30);
		
		t1.setBounds(150, 30, 250, 30);
		t2.setBounds(150, 80, 250, 30);
		t3.setBounds(150, 130, 250, 30);
		t4.setBounds(150, 180, 250, 30);
		t5.setBounds(150, 230, 250, 30);
		//t7.setBounds(100, 280, 100, 30);
		Dept.setBounds(150, 280, 250, 30);
		
		 Designation.setBounds(150, 330, 250, 30);
		
		
		b1.setBounds(50,400 ,80 , 30);
		b2.setBounds(150,400,80,30);
		b3.setBounds(250, 400, 100,30);
		
		JPanel p1=new JPanel();
		p1.setBounds(0, 0, 900, 500);
		 p1.setBackground(Color.cyan );
		

		
		f1.add(l1);
		f1.add(l2);
		f1.add(l3);
		f1.add(l4);
		f1.add(l5);
		f1.add(l6);
		f1.add(l7);
		f1.add(l8);
		f1.add( Designation);
		f1.add( Dept);
		
		
		f1.add(b1);
		f1.add(b2);
		f1.add(b3);
		
		
		f1.add(t1);
		f1.add(t2);
		f1.add(t3);
		f1.add(t4);
		f1.add(t5);
		f1.add(t7);
		f1.add(p1);
	//	f1.add(t8);
		b1.addActionListener(this);
		  b2.addActionListener(this);
		  b3.addActionListener(this);
		  Designation.addActionListener(this);
		  
		 
		
		
		f1.setSize(900, 500);
		f1.setTitle("ADD USER");
        f1.setLayout(null);
        f1.setLocationRelativeTo(null);
        
        f1.setVisible(true);
        try{
        	Class.forName("com.mysql.jdbc.Driver");
        	  con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Library","root","root");
        	 stmt = con.createStatement();
      	 if(con!=null)
        	 {
        		 JOptionPane.showMessageDialog(null, "connected to database"); 
        	 }
             
        }catch(Exception ex)
        {
        	JOptionPane.showMessageDialog(null,ex.getMessage());
        }


        }
	
	public void actionPerformed(ActionEvent e)
		{
		if(e.getSource()==b1)
		{
			try{
				  String in1=t1.getText();
				  String in2=t2.getText();
				  String in3=t3.getText();
				  String in4=t4.getText();
				  String in5=t5.getText();
				  //String in7=t7.getText();
				  String in7 = Dept.getSelectedItem().toString();
					 
				  String in6 = Designation.getSelectedItem().toString();
				 
				
				
				 
				 
				 
 Pattern pattern1 = Pattern.compile("(\\+91[\\-\\s]?)?[0]?(91)?[789]\\d{9}$");
  Matcher mat1 = pattern1.matcher(in5);
				 
 Pattern pattern = Pattern.compile("[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}");
 Matcher mat = pattern.matcher(in3);
 
 Pattern pattern2 = Pattern.compile("[a-z0-9].{7,10}");
 Matcher mat2 = pattern2.matcher(in2);
 
 
 
 
		  if(mat.matches()&&mat1.matches()&&mat2.matches())
			   {
				
  pst= (PreparedStatement) con.prepareStatement("insert into User(Name,ID,E_mail,Address,Contact,Dept,Designation) values(?,?,?,?,?,?,?)");
  
  pst.setString(1, in1);
  pst.setString(2, in2);
  pst.setString(3, in3);
  pst.setString(4, in4);
  pst.setString(5, in5);
  pst.setString(6, in7);
  pst.setString(7, in6);
	 
 
				
	 pst.executeUpdate();
	 JOptionPane.showMessageDialog(null, "data inserted");
		   }
		    else
		    {

				           
		  	JOptionPane.showMessageDialog(null,"notvalid e-mail and Mobile No");
				        }
				  
				  
			  }catch(SQLException e2){
				  JOptionPane.showMessageDialog(null, e2.getMessage());
				  
				  
			  }
			  
		  }
		  
		if(e.getSource()==b2)
		{
			new interface1();
			
		}
		
		
		if(e.getSource()==b3)
		{
			try{
				String data1 =null;
				stmt=con.createStatement();
				rst=stmt.executeQuery("select  * from User  ");
				rst1=rst.getMetaData();
				int c=rst1.getColumnCount();
				Vector column=new Vector(c);
				for(int i=1;i<=c;i++)
				{
					column.add(rst1.getColumnName(i));
					
				}
				Vector data= new Vector();
				Vector row =new Vector();
				while(rst.next())
					
				{
					row=new Vector(c);
					for(int i=1;i<=c;i++)
					{
						row.add(rst.getString(i));
						
					}
					data.add(row);
				}
				JFrame frame=new JFrame();
				frame.setSize(700, 500);
				frame.setLocationRelativeTo(null);
				frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				JPanel panel = new JPanel();
				JTable table =new JTable(data,column);
				JScrollPane jsp=new JScrollPane(table);
				
				
				panel.setLayout(new BorderLayout());
				panel.add(jsp,BorderLayout.CENTER);
				frame.setContentPane(panel);
				frame.setVisible(true);
			}
				
			catch(Exception e2)
			
			{
				e2.printStackTrace();
			}
				
			}
		}
		
		
		
		
		
		  
				
		

			
		
		
		
		
	
	
	public static void main(String args[])
	{
		new User();
	}
	
	

}

