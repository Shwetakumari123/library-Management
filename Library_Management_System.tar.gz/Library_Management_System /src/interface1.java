import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Calendar;
import java.util.Vector;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;

import com.mysql.jdbc.PreparedStatement;


public class interface1 extends JFrame implements ActionListener{
	Container c;
	JButton b1,b2,b3,b4,b5,b6,b7,b8,login;
	JLabel l11,l22;
	JTextField t1;
	JPasswordField t2;
	JFrame f1= new JFrame();
	JPanel p1=new JPanel();
	JPanel p2=new JPanel();
	JPanel p3=new JPanel();
	Connection con;
	Statement stmt;
	ResultSet rst;
	PreparedStatement pst;
	java.sql.ResultSetMetaData rst1;
	
	
	
	interface1(){
		c=getContentPane();
		
		b1= new JButton("USER");
		 b2= new JButton("SEARCH BOOKS");
		 b3= new JButton("ISSUE BOOKS");
		 b4= new JButton("BOOKS");
		 b5= new JButton("SHOW BOOKS");
		 b6= new JButton("RETURN BOOKS");
		 b7= new JButton("ABOUT");
		 b8= new JButton("LOGOUT");
		
		b1.setBounds(300, 700, 100,30);
		b2.setBounds(220, 600, 150, 30);
		b3.setBounds(390, 600, 150, 30);
		b4.setBounds(550, 600, 100, 30);
		b5.setBounds(100, 690, 150, 30);
		b6.setBounds(280, 690, 150, 30);
		b7.setBounds(470, 690, 100, 30);
		
		
		b8.setBounds(580, 690, 100, 30);
		 
		b1.setForeground(Color.black);
		b2.setForeground(Color.black);
		b3.setForeground(Color.black);
		b4.setForeground(Color.black);
		b5.setForeground(Color.black);
		b6.setForeground(Color.black);
		b7.setForeground(Color.black);
		b8.setForeground(Color.black);
	
		
		JLabel l1=new JLabel("INDIAN INSTITUTE OF INFORMATION TECHNOLOGY");
		JLabel l2=new JLabel("CENTRAL LIBRARY");
		f1.setTitle("LIBRARY MANAGEMENT");
		f1.setLayout((null));
		f1.setSize(800,700);
		
f1.add(l1);
f1.add(l2);
	l1.setBounds(150, 10,800, 50);
	l2.setBounds(300,100,400,50);
		Font f= new Font("Italic" ,Font.ITALIC,25);
		Font f2= new Font("Italic" ,Font.ITALIC,20);
		l1.setFont(f);
		l2.setFont(f2);
		
		
		l1.setForeground(Color.BLUE);		
		JLabel label=new JLabel();	
		JLabel label2=new JLabel();
		label.setIcon(new ImageIcon("/home/shweta/workspace/LibraryProject/img/images.png"));	
		label2.setIcon(new ImageIcon("/home/shweta/workspace/LibraryProject/img/books.jpg"));
		label.setBounds(10, 10,150, 100);
		label2.setBounds(0, 0, 400, 300);
		JButton btn=new JButton("NEXT");
		btn.setBounds(570, 600, 80, 40);
		
		
		l11=new JLabel("Username");
		l22=new  JLabel("Password");
		login=new JButton("Login");
		t1=new JTextField(20);
		t2=new JPasswordField(20);
		
		

		b1.setBounds(410, 40, 200, 30);
		b2.setBounds(630, 40, 200, 30);
		b3.setBounds(630, 80, 200, 30);
		b4.setBounds(410, 80, 200, 30);
		b5.setBounds(630, 120, 200, 30);
		b6.setBounds(630, 160, 200, 30);
		b7.setBounds(410, 150, 200, 30);
		b8.setBounds(500, 190, 200, 30);
		

		l11.setBounds(350, 600, 150,30);
		t1.setBounds(350, 700, 150,30);
		l22.setBounds(450, 750, 150, 30);

		
		t2.setBounds(350, 700, 50, 30);
		login.setBounds(390, 750, 150, 30);
		
		p2.setLayout(null);
		
		p1.setBounds(0, 0, 900, 100);
		p2.setBounds(0, 200, 900, 400);
		 p3.setBounds(0, 0, 900, 200);
		 p3.setBackground(Color.cyan);

		
		p2.add(label2);
		p2.add(b1);
		p2.add(b2);
		p2.add(b3);
		p2.add(b4);
		p2.add(b5);
		p2.add(b6);
		p2.add(b7);
		p2.add(b8);
		
		p1.add(l11);
		p1.add(t1);
		p1.add(l22);
		
		p2.add(t2);
		p2.add(login);
	p3.add(label);
	p3.setLayout(null);
		
		f1.add(p2);
		f1.add(p3);
		//f1.add(p1);
		 b1.addActionListener(this);
		  b2.addActionListener(this);
		  b3.addActionListener(this);
		  b4.addActionListener(this);
		  b5.addActionListener(this);
		  b6.addActionListener(this);
		  b7.addActionListener(this);
		  b8.addActionListener(this);
		  login.addActionListener(this);
		  
		  p2.setBackground(Color.cyan);
		p1.setBackground(Color.BLUE);
		
		btn.setBackground(Color.BLUE);
		f1.setSize(900, 500);
		//f1.add(label);
		//f1.add(label2);
		f1.setVisible(true);
		//f1.setBackground(Color.BLUE);
		f1.setLocationRelativeTo(null);
		f1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);		
		 try{
	        	Class.forName("com.mysql.jdbc.Driver");
	        	  con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Library","root","root");
	        	 stmt = con.createStatement();
	        	 if(con!=null)
	        	 {
	        		 JOptionPane.showMessageDialog(null, "connected to database"); 
	        	 }
	             
	        }catch(Exception ex)
	        {
	        	JOptionPane.showMessageDialog(null,ex.getMessage());
	        }


	        }

		
	
	public void actionPerformed(ActionEvent e)
	{
		
		if(e.getSource()==login){
			try{
		
	f1.remove(p2);
	f1.add(p1);
			}catch(Exception e1)
			{
				e1.printStackTrace();
			}
		}
	
   
  
		
		
		
	if(e.getSource()==b3)
	{
		new IssueofBooks();
	
	}
	if(e.getSource()==b4)
	{
		new Book();
	
	}
	if(e.getSource()==b1)
	{
		new User();
	
	}
	if(e.getSource()==b6)
	{
		new ReturnBooks();
	
	}
	if(e.getSource()==b2)
	{
		new SearchBookLibrarian();
	
	}
	if(e.getSource()==b5)
	{

		try{
			String data1 =null;
			stmt=con.createStatement();
			rst=stmt.executeQuery("select  * from Books  ");
			rst1=rst.getMetaData();
			int c=rst1.getColumnCount();
			Vector column=new Vector(c);
			for(int i=1;i<=c;i++)
			{
				column.add(rst1.getColumnName(i));
				
			}
			Vector data= new Vector();
			Vector row =new Vector();
			while(rst.next())
				
			{
				row=new Vector(c);
				for(int i=1;i<=c;i++)
				{
					row.add(rst.getString(i));
					
				}
				data.add(row);
			}
			JFrame frame=new JFrame();
			frame.setSize(900, 500);
			frame.setLocationRelativeTo(null);
			frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			JPanel panel = new JPanel();
			JTable table =new JTable(data,column);
			JScrollPane jsp=new JScrollPane(table);
			
			
			panel.setLayout(new BorderLayout());
			panel.add(jsp,BorderLayout.CENTER);
			frame.setContentPane(panel);
			frame.setVisible(true);
		}
			
		catch(Exception e2)
		
		{
			e2.printStackTrace();
		}
			
		}
	
	
	if(e.getSource()==b7)
	{
		new Book();
	
	}
	if(e.getSource()==b8)
	{
		new Login();
	
	}
		
	}

	
	public static void main(String[] args)
	{
		 
	            	new interface1 ();
	}
	
	
	}
	
	

