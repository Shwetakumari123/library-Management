import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;

import com.mysql.jdbc.PreparedStatement;


public class AddLibrarian1 extends JFrame implements ActionListener {
	
	JLabel l1,l2,l3,l4,l5,l6,l7,l8;
	JTextField t1,t2,t3,t4,t5,t6,t7,t8;
	JButton b1,b2,b3,b4;
	Connection con;
	Statement stmt;
	ResultSet rst;
	PreparedStatement pst;
	java.sql.ResultSetMetaData rst1;
	JPanel p1=new JPanel();
	
	
	
	public AddLibrarian1 ()
	{
		JFrame f1=new JFrame();
		l6=new JLabel("YOU ARE LOGGED IN AS ADMIN");
		 Font f= new Font("Italic" ,Font.ITALIC,25);
		 l6.setFont(f);
		l1=new JLabel("Full_Name");
		l2=new JLabel("Login_name");
		l3=new JLabel("E-mail");
		l4=new JLabel("Address");
		l5=new JLabel("Contact");
		l7=new JLabel("Password");
		
		b1=new JButton("Add");
		b2=new JButton("Back");
		b3=new JButton("Delete");
		b4=new JButton("View");
		
		t1=new JTextField(20);
		t2=new JTextField(20);
		t3=new JTextField("eg s@gmail.com");
		t4=new JTextField(20);
		t5=new JTextField("Enter 10 digit mobile No");
		t7=new JPasswordField("20");		
		
		
		 p1.setBounds(0, 0, 900, 500);
		 p1.setBackground(Color.cyan);
		  
		l6.setBounds(250, 0, 450, 30);
		
		l1.setBounds(30, 30, 100, 30);
		l2.setBounds(30, 80, 100, 30);
		l3.setBounds(30, 130, 100, 30);
		l4.setBounds(30, 180, 100, 30);
		l5.setBounds(30, 230, 100, 30);
		l7.setBounds(30, 280, 100, 30);
		
		t1.setBounds(150, 30, 150, 30);
		t2.setBounds(150, 80, 150, 30);
		t3.setBounds(150, 130, 150, 30);
		t4.setBounds(150, 180, 150, 30);
		t5.setBounds(150, 230, 150, 30);
		t7.setBounds(150, 280, 150, 30);
		
		
		
		b1.setBounds(400,100 ,200 , 30);
		b2.setBounds(400,150,200,30);
		b3.setBounds(400, 200, 200,30);
		b4.setBounds(400, 300, 200,30);
		
		
		p1.add(l1);
		p1.add(l2);
		p1.add(l3);
		p1.add(l4);
		p1.add(l5);
		p1.add(l6);
		p1.add(l7);
		
		p1.add(b1);
		p1.add(b2);
		p1.add(b4);
	//	p1.add(b3);
		
		
		p1.add(t1);
		p1.add(t2);
		p1.add(t3);
		p1.add(t4);
		p1.add(t5);
		p1.add(t7);
		f1.add(p1);
		 p1.setLayout(null);
		
		b1.addActionListener(this);
		  b2.addActionListener(this);
		  b3.addActionListener(this);
		  b4.addActionListener(this);
			 
		 
		
		
		f1.setSize(900, 500);
		f1.setTitle("Add Librarian");
        f1.setLayout(null);
        f1.setLocationRelativeTo(null);

        
        f1.setVisible(true);
        try{
        	Class.forName("com.mysql.jdbc.Driver");
        	  con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Library","root","root");
        	 stmt = con.createStatement();
        	 if(con!=null)
        	 {
        		 JOptionPane.showMessageDialog(null, "connected to database"); 
        	 }
             
        }catch(Exception ex)
        {
        	JOptionPane.showMessageDialog(null,ex.getMessage());
        }


        }
	
	public void actionPerformed(ActionEvent e)
		{
		if(e.getSource()==b1)
		{
			try{
				  String in1=t1.getText();
				  String in2=t2.getText();
				 String in3=t3.getText();
				  String in4=t4.getText();
				 String in5=t5.getText();
				  String in7=t7.getText();
				
				  Pattern pattern1 = Pattern.compile("(\\+91[\\-\\s]?)?[0]?(91)?[789]\\d{9}$");
			        Matcher mat1 = pattern1.matcher(in5);
				 
				  Pattern pattern = Pattern.compile("[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[c][om]{2,4}");
			        Matcher mat = pattern.matcher(in3);
			         Pattern pattern2 = Pattern.compile("[a-z0-9].{6,10}");	         	         
			         
			         Matcher mat2 = pattern2.matcher(in7);
			        
 Pattern pattern3 = Pattern.compile("[a-zA-Z].{2,20}");	         	         
			         
			         Matcher mat3 = pattern3.matcher(in1);
			         
			         
				        
			         Pattern pattern4 = Pattern.compile("[a-zA-Z0-9].{4,10}");	         	         
			        			         
			        			         Matcher mat4 = pattern4.matcher(in2);
			        			        
			        	
			        
			         
			         
			         
			        if(mat1.matches()&&mat2.matches()&&mat.matches()&&mat3.matches()&&mat4.matches())
			        	
			        	
			        {	
			        	  pst=(PreparedStatement) con.prepareStatement("insert into Librarian(Full_Name,Login_Name,E_mail,Address,Contact,Password) values(?,?,?,?,?,md5(?))");
					        
						  pst.setString(1, in1);
						  pst.setString(2, in2);
						  pst.setString(3, in3);
						  pst.setString(4, in4);
						  pst.setString(5, in5);
						  pst.setString(6, in7);
						  
						
						  pst.executeUpdate();
					        
					       
						  JOptionPane.showMessageDialog(null, "data inserted");
						  
			        }
			        else{

				           
			        	JOptionPane.showMessageDialog(null,"notvalid e-mail or Mobile No or Please check your password it must have  atleast 6 chracter and atmost 10 chracter ");
			        }
			        
			   
			  }catch(SQLException e2){
				  JOptionPane.showMessageDialog(null, e2.getMessage());
				  
				  
			  
			e2.printStackTrace();
			  
		  }
		}
			
			if(e.getSource()==b2)
			{
				new Login();
			}
		
	
	
	
	
	
	if(e.getSource()==b4)  //view button
			
		{
		try{
			String data1 =null;
			stmt=con.createStatement();
			rst=stmt.executeQuery("select  * from Librarian   ");
			rst1=rst.getMetaData();
			int c=rst1.getColumnCount();
			Vector column=new Vector(c);
			for(int i=1;i<=c;i++)
			{
				column.add(rst1.getColumnName(i));
				
			}
			Vector data= new Vector();
			Vector row =new Vector();
			while(rst.next())
				
			{
				row=new Vector(c);
				for(int i=1;i<=c;i++)
				{
					row.add(rst.getString(i));
					
				}
				data.add(row);
			}
			JFrame frame=new JFrame();
			frame.setSize(800, 500);
			frame.setLocationRelativeTo(null);
			frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			JPanel panel = new JPanel();
			JTable table =new JTable(data,column);
			JScrollPane jsp=new JScrollPane(table);
			
			
			panel.setLayout(new BorderLayout());
			panel.add(jsp,BorderLayout.CENTER);
			frame.setContentPane(panel);
			frame.setVisible(true);
		}
		
			
		catch(Exception e2)
		
		{
			e2.printStackTrace();
		}
			
		}
		  
		}		
		

			
		
		
		
		
	
	
	public static void main(String args[])
	{
		new AddLibrarian1();
	}
	
	

}

