import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import com.mysql.jdbc.PreparedStatement;

public class Login extends JFrame implements ActionListener  {
	JLabel l1,l2,label1;
	JTextField t1,t2;
	JButton b1,b2;
	JFrame f1;
	Connection con;
	Statement stmt;
	ResultSet rst;
	JPanel p1=new JPanel();
	JPanel p2=new JPanel();
	PreparedStatement pst;
	java.sql.ResultSetMetaData rst1;
	boolean flag = false;
	
	

  public Login ()
  {
	
	  l1=new JLabel("Username");
	  l2=new JLabel("Password");
	  JLabel label=new JLabel("LIBRARY MANAGEMENT SYSTEM");
	  JLabel l11=new JLabel("INDIAN INSTITUTE OF INFORMATION TECHNOLOGY");
	  label.setBounds(150, 10,800, 50);
	  
	  Font f2= new Font("Italic" ,Font.ITALIC,45);
	  Font f= new Font("Italic" ,Font.ITALIC,25);
	  label.setFont(f2);
	  l11.setFont(f);
	 // l11.setForeground(Color.BLUE);
	 
	  t1=new JTextField(20);
	  t2=new JPasswordField(10);
	  b1 =new JButton("Login");
	  b2=new JButton("Exit");
	  
	  l11.setBounds(180, 50,800, 50);
	  l1.setBounds(50, 0, 100, 80);
	  l2.setBounds(50,40,100,80);
	  t1.setBounds(180,25,150,30);

	  t2.setBounds(180,65,150,30);

	  b1.setBounds(200,150,80,30);

	  b2.setBounds(190,100,80,30);
	  p2.setBounds(0, 0, 900, 200);
	  p1.setBounds(0, 200, 900, 300);
	  
	//  label1.setIcon(new ImageIcon("/home/shweta/workspace/LibraryProject/img/images.png"));
	 // label1.setBounds(10, 10,150, 100);
	  p1.setBackground(Color.cyan);
	  p2.setBackground(Color.LIGHT_GRAY);
	  p1.setLayout(null);
	  
	  
	  f1=new JFrame();
	  
	  
	// f1.add(label1);
	  p1.add(l1);
	  p1.add(l2);

	  p1.add(t1);

	  p1.add(t2);

	  p1.add(b1);

	  //p1.add(b2);
	  f1.add(l11);
	  f1.add(label);
	  f1.add(p1);
	  f1.add(p2);
	 // f1.setBackground(Color.cyan);
	  
	  b1.addActionListener(this);
	  b2.addActionListener(this);
	  
	  
	  
	  
f1.setSize(900, 500);

f1.setTitle("LIBRARY MANGEMENT SYSTEM");
f1.setLayout(null);
f1.setLocationRelativeTo(null);

f1.setVisible(true);

try{
	Class.forName("com.mysql.jdbc.Driver");
	  con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Library","root","root");
	  stmt = con.createStatement();
	  if(con!=null)
	 {
		 JOptionPane.showMessageDialog(null, "connected to database"); 
	 }
     
}catch(Exception ex)
{
	JOptionPane.showMessageDialog(null,ex.getMessage());
}


  }
  @Override
   public void actionPerformed(ActionEvent e) {
	
   if(e.getSource()==b1);
    {
	  try {

		String in1=t1.getText();
		
		String in2= t2.getText();
	

		pst=(PreparedStatement) con.prepareStatement("select * from User where Name=? and Id=?");
		
		pst.setString(1, in1);
		pst.setString(2, in2);
		rst=pst.executeQuery();

	    if (rst.next()) {
	    	new SearchBook2();
	        JOptionPane.showMessageDialog(null, "you are succesfully logged in");  
	    }
	    //else{
	        // JOptionPane.showMessageDialog(null, "Please Check Username and Password ");
	//} 
	}	
		
	 catch (SQLException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
   }
   }
   if(e.getSource()==b1)
    try{

	String in1=t1.getText();
	
	String in2=t2.getText();


	pst=(PreparedStatement) con.prepareStatement("select * from Librarian where Login_Name=? and Password=md5(?)");
	
	pst.setString(1, in1);
	pst.setString(2, in2);
	rst=pst.executeQuery();

    if (rst.next()) {
    	new interface1();
        //JOptionPane.showMessageDialog(null, "you are succesfully logged in");  
    }
    //else
    //{
        // JOptionPane.showMessageDialog(null, "Please Check Username and Password ");
    //} 
    
	
	
	
	
    }catch (SQLException e1)
    {
    	 JOptionPane.showMessageDialog(null, "Please Check Username and Password ");
	//e1.printStackTrace();
	
    }

	
    
  if(t1.getText().equals( "admin") && t2.getText().equals("admin"))
	  
  {
	  new AddLibrarian1();
	  
  }
//  else
// {
	//  JOptionPane.showMessageDialog(null, "enter correct username");
//  }

  }

     public static void main(String args[])
    {
	  new Login();
	  
    }
    }

	  
	 
