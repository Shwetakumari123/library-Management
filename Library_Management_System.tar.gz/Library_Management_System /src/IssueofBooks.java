import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.format.DateTimeFormatter;
import java.util.Vector;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import java.util.Calendar;
import java.util.Date;
import java.util.Properties;

import org.jdatepicker.impl.*;
import org.jdatepicker.util.*;
import org.jdatepicker.*;

import org.jdatepicker.impl.JDatePanelImpl;
import org.jdatepicker.impl.JDatePickerImpl;
import org.jdatepicker.impl.UtilDateModel;

import com.mysql.jdbc.PreparedStatement;

public class IssueofBooks extends JFrame implements ActionListener{
	JPanel p1,p2;
	JLabel l,l1,l2,l3,l4,l5,l6,l7;
	JTextField t1,t2,t3,t4,t5,t6,t7;
	JButton b1,b2,b3,b4,b5;
	
	Connection con;
	Statement stmt;
	ResultSet rst,rs1;
	JComboBox  Designation;
	PreparedStatement pst,pst1,pst2;
	java.sql.ResultSetMetaData rst1;
	
	
	
	public IssueofBooks()
	{
		JFrame f1=new JFrame();
		
		l1=new JLabel("User_ID");
		l2=new JLabel("Designation");
		l3=new JLabel("Access_No");
		
		l4=new JLabel("ISBN");
		l5=new JLabel("Title");
		l6=new JLabel("Issued_Date");
		l7=new JLabel("Due_Date");
		
		
		
		t1=new JTextField("It must contains atleast 8 digit and starts with 15,16 eg 15010103");
		t2=new JTextField("It must Start with CS or EC and contains atleast 6digit eg CS1234");
		t3=new JTextField("10 or 13 digit 0-596-52068-9");
		t4=new JTextField(20);
		t5=new JTextField("eg 2017-04-03");
		t6=new JTextField(" eg 2017-04-03");
		
		
		
		
		           
	
	
		
		b1=new JButton("Check The No Of Books User have ");
		b2=new JButton("Issue");
		b3=new JButton("view");
		b4=new JButton("Back");
		b5=new JButton("Check Availability of Books  ");
		
		

		l1.setBounds(80, 30, 200, 30);
		l2.setBounds(80, 80, 200, 30);
		l3.setBounds(80, 130, 200, 30);
		//l4.setBounds(80, 180, 200, 30);
		//l5.setBounds(80, 230, 200, 30);		
		l6.setBounds(80, 180, 200, 30);
		l7.setBounds(80, 230, 200, 30);
		
		
		
		
		t1.setBounds(190, 30, 400, 30);
		
		t2.setBounds(190, 130, 400, 30);
		//t3.setBounds(190, 180, 400, 30);
		//t4.setBounds(190, 230, 400, 30);
		t5.setBounds(190, 180, 400, 30);
		t6.setBounds(190, 230, 400, 30);
		  
	    	Designation = new JComboBox();
		   Designation.addItem("Student");
			 Designation.addItem("Faculty");
			 Designation.addItem("Tecnical Staff");
			 Designation.setBounds(190,80,250, 30);
			
			
				
		
	
		
		b1.setBounds(50,400 ,300 , 30);
		b2.setBounds(370,400,150,30);
		b3.setBounds(550, 400, 150,30);
		b4.setBounds(320, 440, 150,30);
		b5.setBounds(550, 440, 250,30);
		
		
		JPanel p1=new JPanel();
		p1.setBounds(0, 0, 900, 500);
		 p1.setBackground(Color.cyan );
		
		f1.add(l1);
		f1.add(l2);
		f1.add(l3);
		//f1.add(l4);
		//f1.add(l5);
		f1.add(l6);
		f1.add(l7);
		

		f1.add(t1);
		f1.add( Designation);
		
		f1.add(t2);
	//	f1.add(t3);
	//	f1.add(t4);
		f1.add(t5);
		f1.add(t6);
		
		f1.add(b1);
		f1.add(b2);
		f1.add(b3);
		f1.add(b4);
		f1.add(b5);
		f1.add(p1);
		
		 b1.addActionListener(this);
		  b2.addActionListener(this);
		  b3.addActionListener(this);
		  b4.addActionListener(this);
		  b5.addActionListener(this);



		  
		
		

		f1.setSize(900, 500);
        f1.setLayout(null);
        f1.setLocationRelativeTo(null);
       
		
	
		f1.setTitle("ISSUE OF BOOKS");
		f1.setVisible(true);
		f1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		
		 try{
	        	Class.forName("com.mysql.jdbc.Driver");
	        	  con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Library","root","root");
	        	 stmt = con.createStatement();
	        	 if(con!=null)
	        	 {
	        		 JOptionPane.showMessageDialog(null, "connected to database"); 
	        	 }
	             
	        }catch(Exception ex)
	        {
	        	JOptionPane.showMessageDialog(null,ex.getMessage());
	        }


	        }
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==b2)
		{
		// TODO Auto-generated method stub
		try{
			  String in1=t1.getText();
			  String in2 = Designation.getSelectedItem().toString();
				 
			//  int in3=Integer.parseInt(t2.getText());
			  String in3=t2.getText();
			 
			// String in4=t3.getText();
			// String in5=t4.getText();
			  String in6=t5.getText();
			 String in7=t6.getText();
			 
			
		       //Access NO VAlidation
		        
		      // Pattern pattern3 = Pattern.compile("[CE]+[SC].{6,10}");
		      //  Matcher mat = pattern3.matcher(in3);
		        
		        //ID Validation
		        
		      //  Pattern pattern = Pattern.compile("[12]+[567].{6,10}");
		     //   Matcher mat1 = pattern.matcher(in1);
		        
			 
			 
		
		     //   if(mat.matches()&&mat1.matches())
		     //  {  
			 
			
  pst=(PreparedStatement) con.prepareStatement("insert into User_Books(ID,Designation,access_No,Issued_date,due__date ) values(?,?,?,?,?) ");
			  
			 // pst1=(PreparedStatement) con.prepareStatement("update Books set Remaining_Copies=NoofCopies-(select count(Title) from User_Books where Books.Title=User_Books.Title and Books.BookIsbn=User_Books.BookIsbn);");
  pst.setString(1, in1);
  pst.setString(2, in2);
			  
 // pst.setInt(3, in3);
  pst.setString(3, in3);
  
//  pst.setString(4, in4);
 // pst.setString(5, in5);
  pst.setString(4, in6);
  pst.setString(5, in7);
			
			 
			 
			  pst.executeUpdate();
			// pst1.executeUpdate();
			  JOptionPane.showMessageDialog(null, "Book Issued");
		//	 } 
			  
			  //else{

		           
		        //	JOptionPane.showMessageDialog(null," Chech  ID and Access No");
		     //  }
		  }
		catch(SQLException e2){
			  JOptionPane.showMessageDialog(null, e2.getMessage());
			  
			  
		  }
		
	  }
		
		if(e.getSource()==b1)
		{
			new SearchUserBooks();
		}
		
			if(e.getSource()==b3)
			{
				try{
					String data1 =null;
					stmt=con.createStatement();
					rst=stmt.executeQuery("select ID,Name,Designation, access_No,BookIsbn,Title,Issued_date,due__date from User natural join User_Books natural join Books ");
					rst1=rst.getMetaData();
					int c=rst1.getColumnCount();
					Vector column=new Vector(c);
					for(int i=1;i<=c;i++)
					{
						column.add(rst1.getColumnName(i));
						
					}
					Vector data= new Vector();
					Vector row =new Vector();
					while(rst.next())
						
					{
						row=new Vector(c);
						for(int i=1;i<=c;i++)
						{
							row.add(rst.getString(i));
							
						}
						data.add(row);
					}
					JFrame frame=new JFrame();
					frame.setSize(900, 500);
					frame.setLocationRelativeTo(null);
					frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
					JPanel panel = new JPanel();
					JTable table =new JTable(data,column);
					JScrollPane jsp=new JScrollPane(table);
					
					
					panel.setLayout(new BorderLayout());
					panel.add(jsp,BorderLayout.CENTER);
					frame.setContentPane(panel);
					frame.setVisible(true);
				}
					
				catch(Exception e2)
				
				{
					e2.printStackTrace();
				}
					
				}
			
			if(e.getSource()==b4){
				new interface1();
			}
			

			if(e.getSource()==b5){
				new SearchBook2();
			}
			}
			
		
			
			
		
	
		public static void main (String[] args)
	{
		new IssueofBooks();
	}

}

		