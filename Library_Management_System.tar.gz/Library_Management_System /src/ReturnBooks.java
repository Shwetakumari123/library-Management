
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Vector;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;

import com.mysql.jdbc.PreparedStatement;

public class ReturnBooks extends JFrame implements ActionListener {
	JPanel p1,p2;
	JLabel l,l1,l2,l3,l4;
	JTextField t1,t2,t3,t4;
	JButton b1,b2,b3,b4;
	JPanel p3=new JPanel();

	Connection con;
	Statement stmt;
	ResultSet rst;
	java.sql.PreparedStatement pst,pst1;
	//PreparedStatement pst1;
	java.sql.ResultSetMetaData rst1;
	
	
	
	public ReturnBooks()
	{
		JFrame f1=new JFrame();
		
		l1=new JLabel("User ID");
		l2=new JLabel("Access_No");
		l3=new JLabel("ISBN");
		l4=new JLabel("Title");
		
		t1=new JTextField("It must contains atleast 8 digit and starts with 15,16 eg 15010103");
		t2=new JTextField("It must Start with CS or EC and contains atleast 6digit eg CS1234");
		t3=new JTextField("10 or 13 digit 0-596-52068-9");
		t4=new JTextField(20);
		
		b1=new JButton("Check how many books user is having");
		b2=new JButton("Return");
		b3=new JButton("view");
		b4=new JButton("Back");
		
		
		

		l1.setBounds(100, 30, 80, 30);
		l2.setBounds(100, 80, 80, 30);
		l3.setBounds(10, 130, 80, 30);
		l4.setBounds(10, 180, 80, 30);
		
		t1.setBounds(100, 30, 150, 30);
		t2.setBounds(180, 80, 350, 30);
		t3.setBounds(100, 130, 150, 30);
		t4.setBounds(100, 180, 150, 30);
		
		b1.setBounds(50,270 ,350 , 30);
		b2.setBounds(250,320,150,30);
		b3.setBounds(450, 320, 150,30);
		b4.setBounds(320, 380, 150,30);
		
		
		JPanel p1=new JPanel();
		p1.setBounds(0, 0, 900, 500);
		 p1.setBackground(Color.cyan );


		
		
	//	f1.add(l1);
		f1.add(l2);
	//	f1.add(l3);
	//	f1.add(l4);

	//	f1.add(t1);
		f1.add(t2);
		//f1.add(t3);
		//f1.add(t4);
		
		f1.add(b1);
		f1.add(b2);
		f1.add(b3);
		f1.add(b4);
		f1.add(p1);
		
		

		f1.setSize(900, 500);
        f1.setLayout(null);
        f1.setLocationRelativeTo(null);
        
       
		
	
		 f1.setTitle("Return OF BOOKS");
		f1.setVisible(true);
		f1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	 b1.addActionListener(this);
		  b2.addActionListener(this);
		  b3.addActionListener(this);
		  b4.addActionListener(this);

		
		try{
        	Class.forName("com.mysql.jdbc.Driver");
        	  con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Library","root","root");
        	 stmt = con.createStatement();
        	 if(con!=null)
        	 {
        		 JOptionPane.showMessageDialog(null, "connected to database"); 
        	 }
             
        }catch(Exception ex)
        {
        	JOptionPane.showMessageDialog(null,ex.getMessage());
        }


	}
	public void actionPerformed(ActionEvent e) {
		
		
		if(e.getSource()==b1){
			new SearchUserBooks();
		}
		
		// TODO Auto-generated method stub
		if(e.getSource()==b2){
			try{
				String in1=t1.getText();
				 // int in2=Integer.parseInt(t2.getText());
				  String in2=t2.getText();
				 
				 String in3=t3.getText();
				 
				 String in4=t4.getText();
				 
				 
				 //ISBN VAlidation
				 Pattern pattern2 = Pattern.compile( "^(?:ISBN(?:-1[03])?:? )?(?=[0-9X]{10}$|(?=(?:[0-9]+[- ]){3})[- 0-9X]{13}$|97[89][0-9]{10}$|(?=(?:[0-9]+[- ]){4})[- 0-9]{17}$)(?:97[89][- ]?)?[0-9]{1,5}[- ]?[0-9]+[- ]?[0-9]+[- ]?[0-9X]$" );
			       Matcher mat2 = pattern2.matcher(in3);
			       
			       //Access NO VAlidation
			        
			       Pattern pattern3 = Pattern.compile("[CE]+[SC].{6,10}");
			        Matcher mat = pattern3.matcher(in2);
			        
			        //ID Validation
			        
			        Pattern pattern = Pattern.compile("[12]+[567].{6,10}");
			        Matcher mat1 = pattern.matcher(in1);
			        
				 
				 
			
			        if(mat2.matches()&&mat.matches()&&mat1.matches())
			       {  
				 
				 
				 
				 
				 
				
		pst= con.prepareStatement("delete from User_Books  where ID= ? and access_No= ? and BookIsbn = ? and Title = ? ");
				  
				  
	 pst1=(PreparedStatement) con.prepareStatement("update Books set Remaining_Copies=NoofCopies-(select count(Title) from User_Books where Books.Title=User_Books.Title)");
				
				 pst.setString(1, in1);
				  pst.setString(2, in2);
				  
				 pst.setString(3, in3);
				 pst.setString(4, in4);
				 
				  pst.execute();
				 pst1.execute();
				 JOptionPane.showMessageDialog(null, "data deleted");
			       }
				 else{

			           
			        	JOptionPane.showMessageDialog(null," Enter valid ISBN");
			       }
			}catch(Exception ae)
			{
				ae.printStackTrace();
			}
		}
		
		if(e.getSource()==b3){
			
					try{
						String data1 =null;
						stmt=con.createStatement();
						rst=stmt.executeQuery("select  * from User_Books  ");
						rst1=rst.getMetaData();
						int c=rst1.getColumnCount();
						Vector column=new Vector(c);
						for(int i=1;i<=c;i++)
						{
							column.add(rst1.getColumnName(i));
							
						}
						Vector data= new Vector();
						Vector row =new Vector();
						while(rst.next())
							
						{
							row=new Vector(c);
							for(int i=1;i<=c;i++)
							{
								row.add(rst.getString(i));
								
							}
							data.add(row);
						}
						JFrame frame=new JFrame();
						frame.setSize(800, 500);
						frame.setLocationRelativeTo(null);
						frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
						JPanel panel = new JPanel();
						JTable table =new JTable(data,column);
						JScrollPane jsp=new JScrollPane(table);
						
						
						panel.setLayout(new BorderLayout());
						panel.add(jsp,BorderLayout.CENTER);
						frame.setContentPane(panel);
						frame.setVisible(true);
					}
						
					catch(Exception e2)
					
					{
						e2.printStackTrace();
					}
						
				}
		
		
		if(e.getSource()==b4){
			new interface1();
		}
			
		
	}

		public static void main (String[] args)
	{
		new ReturnBooks();
	}
		
}
